Adriaenssens_Requena_OpenGL_1
We added all three object to the screen. The objects are able to be rotated or scaled. 
We had difficulty getting started with this assignemnt, however, once we got the first matrix to work things went a lot smoother. 
We were unable to reset the rotations correctly.

Using the widgets along the left of the screen, the use can turn the dials to rotate the shapes, or drag the slider to changed the object's scale.


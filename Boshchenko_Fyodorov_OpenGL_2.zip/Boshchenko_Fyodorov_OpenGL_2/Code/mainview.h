#ifndef MAINVIEW_H
#define MAINVIEW_H

#define  SIZE 11862
#include "model.h"
#include "vertex.h"

#include <QKeyEvent>
#include <QMouseEvent>
#include <QOpenGLWidget>
#include <QOpenGLFunctions_3_3_Core>
#include <QOpenGLDebugLogger>
#include <QOpenGLShaderProgram>
#include <QTimer>
#include <QVector3D>
#include <memory>
#include <QMatrix4x4>

class MainView : public QOpenGLWidget, protected QOpenGLFunctions_3_3_Core {
    Q_OBJECT

    QOpenGLDebugLogger *debugLogger;
    QTimer timer; // timer used for animation

    QOpenGLShaderProgram shaderProgramNormal, shaderProgramPhong, shaderProgramGouraud;

public:
    enum ShadingMode : GLuint
    {
        PHONG = 0, NORMAL, GOURAUD
    };

    MainView(QWidget *parent = 0);
    ~MainView();

    // Functions for widget input events
    void setRotation(int rotateX, int rotateY, int rotateZ);
    void setScale(int scale);
    void setShadingMode(ShadingMode shading);



protected:
    void initializeGL();
    void resizeGL(int newWidth, int newHeight);
    void paintGL();

    // Functions for keyboard input events
    void keyPressEvent(QKeyEvent *ev);
    void keyReleaseEvent(QKeyEvent *ev);

    // Function for mouse input events
    void mouseDoubleClickEvent(QMouseEvent *ev);
    void mouseMoveEvent(QMouseEvent *ev);
    void mousePressEvent(QMouseEvent *ev);
    void mouseReleaseEvent(QMouseEvent *ev);
    void wheelEvent(QWheelEvent *ev);

    // Function for making a vertex
    vertex createVertex(float x, float y, float z, float r, float g, float b, float tX, float tY);
    QVector<quint8> imageToBytes(QImage image);

    // Transforms
    float scale = 1.f;
    QVector3D rotation;
    QMatrix4x4 projectionTransform;

    void loadMesh();

    void destroyModelBuffers();

    void updateProjectionTransform();
    void updateModelTransforms();
    void updateNormalsTransforms();



private slots:
    void onMessageLogged( QOpenGLDebugMessage Message );

private:
    void createShaderProgram();
    int opt = 0;
    GLuint meshVBO;
    GLuint meshVAO;
    GLuint textureLocation;

    vertex mesh[SIZE];

    GLint proj_locations_N;
    GLint view_locations_N;
    GLint mode_locations_N;
    GLint normal_locations_N;

    GLint proj_locations_P;
    GLint view_locations_P;
    GLint mode_locations_P;
    GLint normal_locations_P;
    GLint light_source_locations_P;
    GLint light_amb_locations_P;
    GLint light_diff_locations_P;
    GLint light_spec_locations_P;
    GLint material_color_locations_P;
    GLint material_amb_locations_P;
    GLint material_diff_locations_P;
    GLint material_spec_locations_P;
    GLint texture_color_locations_P;
    GLint expo_locations_P;

    GLint proj_locations_G;
    GLint view_locations_G;
    GLint mode_locations_G;
    GLint normal_locations_G;
    GLint light_source_locations_G;
    GLint light_amb_locations_G;
    GLint light_diff_locations_G;
    GLint light_spec_locations_G;
    GLint material_color_locations_G;
    GLint material_amb_locations_G;
    GLint material_diff_locations_G;
    GLint material_spec_locations_G;
    GLint texture_color_locations_G;
    GLint expo_locations_G;

    GLfloat lightSource[3] = {-1,-1,-1};
    GLfloat lightAmb[3] = {0.2,0.2,0.2};
    GLfloat lightDiff[3] = {0.3,0.3,0.3};
    GLfloat lightSpec[3] = {0.4,0.4,0.4};

    GLfloat materialColor[3] = {0.5,0.5,0.5};
    GLfloat materialAmb[3] = {0.2,0.2,0.2};
    GLfloat materialDiff[3] = {0.4,0.4,0.4};
    GLfloat materialSpec[3] = {0.2,0.2,0.2};
    const GLfloat pExponent = 2;

    QMatrix4x4 modelTrans;
    QMatrix4x4 modelProj;
    QMatrix4x4 modelView;
    QMatrix3x3 normals;

    int initX = 0, initY = 0, initZ = 0;
    float initS = 100.0f;

    QImage textureRaw;
    QVector<quint8> textureVecs;
};

#endif // MAINVIEW_H

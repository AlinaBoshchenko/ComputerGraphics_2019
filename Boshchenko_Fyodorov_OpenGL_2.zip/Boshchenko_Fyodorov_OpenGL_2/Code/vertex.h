#ifndef VERTEX_H
#define VERTEX_H

struct vertex{
    float x;
    float y;
    float z;
    float red;
    float green;
    float blue;
    float tX;
    float tY;
};

#endif // VERTEX_H


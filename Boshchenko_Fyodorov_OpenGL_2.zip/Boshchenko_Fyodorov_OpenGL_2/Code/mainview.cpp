#include "mainview.h"
#include "math.h"
#include "vertex.h"
#include <QDateTime>
#include <iostream>
#include <QMatrix4x4>
#include <QMatrix3x3>
#include <QVector3D>
#include <random>
#include <string>
using namespace std;


/**
 * @brief MainView::MainView
 *
 * Constructor of MainView
 *
 * @param parent
 */
MainView::MainView(QWidget *parent) : QOpenGLWidget(parent) {
    qDebug() << "MainView constructor";

    connect(&timer, SIGNAL(timeout()), this, SLOT(update()));
}

/**
 * @brief MainView::~MainView
 *
 * Destructor of MainView
 * This is the last function called, before exit of the program
 * Use this to clean up your variables, buffers etc.
 *
 */
MainView::~MainView() {
    debugLogger->stopLogging();

    glDeleteBuffers(1,&meshVBO);
    glDeleteVertexArrays(1,&meshVAO);

    qDebug() << "MainView destructor";
}

// --- OpenGL initialization

/**
 * @brief MainView::initializeGL
 *
 * Called upon OpenGL initialization
 * Attaches a debugger and calls other init functions
 */


void MainView::initializeGL() {
    qDebug() << ":: Initializing OpenGL";
    initializeOpenGLFunctions();

    debugLogger = new QOpenGLDebugLogger(this);
    connect( debugLogger, SIGNAL( messageLogged( QOpenGLDebugMessage ) ),
             this, SLOT( onMessageLogged( QOpenGLDebugMessage ) ), Qt::DirectConnection );

    if ( debugLogger->initialize() ) {
        qDebug() << ":: Logging initialized";
        debugLogger->startLogging( QOpenGLDebugLogger::SynchronousLogging );
        debugLogger->enableMessages();
    }

    QString glVersion;
    glVersion = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    qDebug() << ":: Using OpenGL" << qPrintable(glVersion);

    Model mod = Model(":/models/cat.obj");

    QVector<QVector3D> vecs;
    QVector<QVector3D> norms;
    QVector<QVector2D> coord;


    vecs = mod.getVertices();
    norms = mod.getNormals();
    coord = mod.getTextureCoords();

    for (int i = 0 ; i < vecs.size() ; i++){
        mesh[i] = createVertex(vecs[i][0], vecs[i][1], vecs[i][2], norms[i][0] ,  norms[i][1],  norms[i][2], coord[i][0], coord[i][1]);
    }

    // Enable depth buffer
    glEnable(GL_DEPTH_TEST);

    // Enable backface culling
    glEnable(GL_CULL_FACE);

    // Default is GL_LESS
    glDepthFunc(GL_LEQUAL);

    // Set the color of the screen
    glClearColor(0.2f, 0.1f, 0.3f, 0.0f);

    createShaderProgram();

    modelTrans.setToIdentity();
    modelProj.setToIdentity();
    modelView.setToIdentity();

    modelTrans.translate({0.0f,-2.0f,-10.0f});
    modelTrans.scale((float) 10.0f);

    QVector3D eye = QVector3D(0,0,5);
    QVector3D center = QVector3D(0,0,0);
    QVector3D up = QVector3D(0,1,0);

    modelProj.perspective(45.0f,1.0f,1.0f,100.0f);
    modelView.lookAt(eye,center,up);

    textureRaw = QImage(":/textures/cat.png");
    textureVecs = imageToBytes(textureRaw);
    qDebug() << textureRaw.width() << textureRaw.height();

    glGenBuffers(1, &meshVBO);
    glGenVertexArrays(1, &meshVAO);
    glBindVertexArray(meshVAO);
    glBindBuffer(GL_ARRAY_BUFFER,meshVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(mesh), mesh, GL_STATIC_DRAW);
}

void MainView::createShaderProgram(){
    shaderProgramPhong.addShaderFromSourceFile(QOpenGLShader::Vertex, ":/shaders/vertshader_phong.glsl");
    shaderProgramPhong.addShaderFromSourceFile(QOpenGLShader::Fragment,":/shaders/fragshader_phong.glsl");

    shaderProgramNormal.addShaderFromSourceFile(QOpenGLShader::Vertex, ":/shaders/vertshader_normal.glsl");
    shaderProgramNormal.addShaderFromSourceFile(QOpenGLShader::Fragment,":/shaders/fragshader_normal.glsl");

    shaderProgramGouraud.addShaderFromSourceFile(QOpenGLShader::Vertex, ":/shaders/vertshader_gouraud.glsl");
    shaderProgramGouraud.addShaderFromSourceFile(QOpenGLShader::Fragment,":/shaders/fragshader_gouraud.glsl");

    shaderProgramPhong.link();
    shaderProgramNormal.link();
    shaderProgramGouraud.link();


    //SHADERS
    //NORMAL-----------------------------
    proj_locations_N = shaderProgramNormal.uniformLocation("projection_matrix");
    view_locations_N = shaderProgramNormal.uniformLocation("view_matrix");
    mode_locations_N = shaderProgramNormal.uniformLocation("model_matrix");
    normal_locations_N = shaderProgramNormal.uniformLocation("normal_matrix");

    //PHONG------------------------------
    proj_locations_P = shaderProgramPhong.uniformLocation("projection_matrix");
    view_locations_P = shaderProgramPhong.uniformLocation("view_matrix");
    mode_locations_P = shaderProgramPhong.uniformLocation("model_matrix");
    normal_locations_P = shaderProgramPhong.uniformLocation("normal_matrix");

    light_source_locations_P = shaderProgramPhong.uniformLocation("light_source");
    light_amb_locations_P = shaderProgramPhong.uniformLocation("light_amb");
    light_diff_locations_P = shaderProgramPhong.uniformLocation("light_diff");
    light_spec_locations_P = shaderProgramPhong.uniformLocation("light_spec");

    material_color_locations_P = shaderProgramPhong.uniformLocation("material_color");
    material_amb_locations_P = shaderProgramPhong.uniformLocation("material_amb");
    material_diff_locations_P = shaderProgramPhong.uniformLocation("material_diff");
    material_spec_locations_P = shaderProgramPhong.uniformLocation("material_spec");

    texture_color_locations_P = shaderProgramPhong.uniformLocation("texture_color");
    expo_locations_P = shaderProgramGouraud.uniformLocation("pExpo");

    //GOURAUD-----------------------------
    proj_locations_G = shaderProgramGouraud.uniformLocation("projection_matrix");
    view_locations_G = shaderProgramGouraud.uniformLocation("view_matrix");
    mode_locations_G = shaderProgramGouraud.uniformLocation("model_matrix");
    normal_locations_G = shaderProgramGouraud.uniformLocation("normal_matrix");

    light_source_locations_G = shaderProgramGouraud.uniformLocation("light_source");
    light_amb_locations_G = shaderProgramGouraud.uniformLocation("light_amb");
    light_diff_locations_G = shaderProgramGouraud.uniformLocation("light_diff");
    light_spec_locations_G = shaderProgramGouraud.uniformLocation("light_spec");

    material_color_locations_G = shaderProgramGouraud.uniformLocation("material_color");
    material_amb_locations_G = shaderProgramGouraud.uniformLocation("material_amb");
    material_diff_locations_G = shaderProgramGouraud.uniformLocation("material_diff");
    material_spec_locations_G = shaderProgramGouraud.uniformLocation("material_spec");

    texture_color_locations_G = shaderProgramGouraud.uniformLocation("texture_color");
    expo_locations_G = shaderProgramGouraud.uniformLocation("pExpo");

    //END SHADERS--------------------------
}

// --- OpenGL drawing

/**
 * @brief MainView::paintGL
 *
 * Actual function used for drawing to the screen
 *
 */
void MainView::paintGL() {
    // Clear the screen before rendering
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    switch(opt){
    case(0):
        shaderProgramPhong.bind();

        normals = modelTrans.normalMatrix();

        glClearColor(0.2f, 0.1f, 0.3f, 0.0f);

        glUniformMatrix4fv(proj_locations_P, 1, GL_FALSE, modelProj.data());
        glUniformMatrix4fv(view_locations_P, 1, GL_FALSE, modelView.data());

        glGenTextures(1,&textureLocation);
        glBindTexture(GL_TEXTURE_2D,textureLocation);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,textureRaw.width(),textureRaw.height(),0,GL_RGBA,GL_UNSIGNED_BYTE,textureVecs.data());
        glActiveTexture(GL_TEXTURE1);
        glUniform1i(texture_color_locations_P,1);


        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)offsetof(vertex, red));

        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)offsetof(vertex, tX));

        glUniformMatrix3fv(normal_locations_P, 1, GL_FALSE, normals.data());
        glUniformMatrix4fv(mode_locations_P, 1, GL_FALSE, modelTrans.data());

        glUniform3fv(light_source_locations_P,1,lightSource);
        glUniform3fv(light_amb_locations_P,1,lightAmb);
        glUniform3fv(light_diff_locations_P,1,lightDiff);
        glUniform3fv(light_spec_locations_P,1,lightSpec);

        glUniform3fv(material_color_locations_P,1,materialColor);
        glUniform3fv(material_amb_locations_P,1,materialAmb);
        glUniform3fv(material_diff_locations_P,1,materialDiff);
        glUniform3fv(material_spec_locations_P,1,materialSpec);

        glUniform1f(expo_locations_P,pExponent);

        glDrawArrays(GL_TRIANGLES,0,SIZE);

        shaderProgramPhong.release();
        break;

    case (1):

        shaderProgramNormal.bind();
        normals = modelTrans.normalMatrix();

        glClearColor(0.2f, 0.1f, 0.3f, 0.0f);

        glUniformMatrix4fv(proj_locations_N, 1, GL_FALSE, modelProj.data());
        glUniformMatrix4fv(view_locations_N, 1, GL_FALSE, modelView.data());



        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)offsetof(vertex, red));

        glUniformMatrix3fv(normal_locations_N, 1, GL_FALSE, normals.data());
        glUniformMatrix4fv(mode_locations_N, 1, GL_FALSE, modelTrans.data());

        glDrawArrays(GL_TRIANGLES,0,11862);

        shaderProgramNormal.release();
        break;

    case(2):
        shaderProgramGouraud.bind();

        normals = modelTrans.normalMatrix();

        glClearColor(0.2f, 0.1f, 0.3f, 0.0f);

        glUniformMatrix4fv(proj_locations_G, 1, GL_FALSE, modelProj.data());
        glUniformMatrix4fv(view_locations_G, 1, GL_FALSE, modelView.data());

        glGenTextures(1,&textureLocation);
        glBindTexture(GL_TEXTURE_2D,textureLocation);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,textureRaw.width(),textureRaw.height(),0,GL_RGBA,GL_UNSIGNED_BYTE,textureVecs.data());
        glActiveTexture(GL_TEXTURE1);
        glUniform1i(texture_color_locations_G,1);

        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)offsetof(vertex, red));

        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)offsetof(vertex, tX));

        glUniformMatrix3fv(normal_locations_G, 1, GL_FALSE, normals.data());
        glUniformMatrix4fv(mode_locations_G, 1, GL_FALSE, modelTrans.data());

        glUniform3fv(light_source_locations_G,1,lightSource);
        glUniform3fv(light_amb_locations_G,1,lightAmb);
        glUniform3fv(light_diff_locations_G,1,lightDiff);
        glUniform3fv(light_spec_locations_G,1,lightSpec);
        glUniform3fv(material_color_locations_G,1,materialColor);
        glUniform3fv(material_amb_locations_G,1,materialAmb);
        glUniform3fv(material_diff_locations_G,1,materialDiff);
        glUniform3fv(material_spec_locations_G,1,materialSpec);
        glUniform1fv(expo_locations_G,1,&pExponent);

        glDrawArrays(GL_TRIANGLES,0,11862);

        shaderProgramGouraud.release();
        break;

    default:
        shaderProgramNormal.bind();
        normals = modelTrans.normalMatrix();

        glClearColor(0.2f, 0.1f, 0.3f, 0.0f);

        glUniformMatrix4fv(proj_locations_N, 1, GL_FALSE, modelProj.data());
        glUniformMatrix4fv(view_locations_N, 1, GL_FALSE, modelView.data());

        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)offsetof(vertex, red));

        glUniformMatrix3fv(normal_locations_N, 1, GL_FALSE, normals.data());
        glUniformMatrix4fv(mode_locations_N, 1, GL_FALSE, modelTrans.data());

        glDrawArrays(GL_TRIANGLES,0,11862);

        shaderProgramNormal.release();
        break;
    }

}

/**
 * @brief MainView::resizeGL
 *
 * Called upon resizing of the screen
 *
 * @param newWidth
 * @param newHeight
 */
void MainView::resizeGL(int newWidth, int newHeight)
{
    Q_UNUSED(newWidth)
    Q_UNUSED(newHeight)
    modelProj.setToIdentity();
    modelProj.perspective(60.0f,(float) newWidth / newHeight , 1.0f, 100.0f);
    updateProjectionTransform();
}

void MainView::updateProjectionTransform()
{
    float aspect_ratio = static_cast<float>(width()) / static_cast<float>(height());
    modelProj.setToIdentity();
    modelProj.perspective(60, aspect_ratio, 0.2, 20);
}

void MainView::updateModelTransforms()
{
    modelTrans.setToIdentity();
    modelTrans.translate(0, 0, -10);
    modelTrans.scale(scale);
    modelTrans.rotate(QQuaternion::fromEulerAngles(rotation));

    update();
}

void MainView::updateNormalsTransforms()
{

    normals.setToIdentity();

    update();
}

// --- OpenGL cleanup helpers

void MainView::destroyModelBuffers()
{
    glDeleteBuffers(1, &meshVBO);
    glDeleteVertexArrays(1, &meshVAO);
}

// --- Public interface

void MainView::setRotation(int rotateX, int rotateY, int rotateZ)
{
    rotation = { static_cast<float>(rotateX), static_cast<float>(rotateY), static_cast<float>(rotateZ) };

    modelTrans.setToIdentity();

    modelTrans.rotate(rotateX, 1,0,0);
    modelTrans.rotate(rotateY, 0,1,0);
    modelTrans.rotate(rotateZ, 0,0,1);

    //update();
    updateModelTransforms();

}

void MainView::setScale(int newScale)
{
    scale = static_cast<float>(newScale) / 10.f;

    modelTrans.setToIdentity();

    modelTrans.scale(scale/100.0f);

    updateModelTransforms();
}

void MainView::setShadingMode(ShadingMode shading)
{
    qDebug() << "Changed shading to" << shading;

    opt = shading;
    repaint();
}

// --- Private helpers

/**
 * @brief MainView::onMessageLogged
 *
 * OpenGL logging function, do not change
 *
 * @param Message
 */
void MainView::onMessageLogged( QOpenGLDebugMessage Message ) {
    qDebug() << " → Log:" << Message;
}


vertex MainView::createVertex(float x, float y, float z, float r, float g, float b, float tX, float tY){
    vertex vert;

    vert.x = x;
    vert.y = y;
    vert.z = z;
    vert.red = r;
    vert.green = g;
    vert.blue = b;
    vert.tX = tX;
    vert.tY = tY;

    return vert;
}


